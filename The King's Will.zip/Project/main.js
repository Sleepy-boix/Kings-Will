function Exit() {
    let question = window.prompt('Are you sure you want to leave, if so type: leave');

    if (question != 'leave') {
        console.log('failed');
    }else if (question = 'leave') {
        console.log('sucess')
        window.close();
    }else return false;
}

function About() {
    window.open('./About.html');
}